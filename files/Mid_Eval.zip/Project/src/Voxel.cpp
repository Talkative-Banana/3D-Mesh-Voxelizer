#include <stdio.h>
#include "utils.h"

class Voxel{
public:
	GLint l, b, h;
	glm::vec3 pos;
	GLboolean render;
	GLfloat *expan_vert;

	Voxel(GLint _l, GLint _b, GLint _h, glm::vec3& _pos, GLboolean _render){
		l = _l; b = _b; h = _h;
		pos = _pos;
		render = render;
		display();
	}

	void setrender(GLboolean _render){
		render = _render;
		display();
	}

	void display(){
		if(render){
			return displayVoxel();
		}
	}

	void displayVoxel(){
	    // Vertex Data
	    GLfloat cube_vertices[] = {0, 0, 0,
	                                0, (GLfloat)l ,0,
	                                (GLfloat)b, (GLfloat)l, 0,
	                                (GLfloat)b, 0, 0,
	                                0, 0, (GLfloat)h,
	                                0, (GLfloat)l, (GLfloat)h,
	                                (GLfloat)b, (GLfloat)l, (GLfloat)h,
	                                (GLfloat)b, 0, (GLfloat)h};

	    // Indice Order
	    GLushort cube_indices[] = {0, 1, 2,
	                                0, 3, 2,
	                                0, 3, 7,
	                                0, 4, 7,
	                                0, 1, 5,
	                                0, 4, 5,
	                                4, 7, 6,
	                                4, 5, 6,
	                                1, 2, 6,
	                                1, 5, 6,
	                                3, 7, 6,
	                                3, 2, 6};

	    int nVertices = 6*2*3 ; //(1 face) * (2 triangles each) * (3 vertices each)
	    GLfloat *expanded_vertices = new GLfloat[nVertices*3];
	    for(int i=0; i<nVertices; i++) {
	        expanded_vertices[i*3] = cube_vertices[cube_indices[i]*3];
	        expanded_vertices[i*3 + 1] = cube_vertices[cube_indices[i]*3+1];
	        expanded_vertices[i*3 + 2] = cube_vertices[cube_indices[i]*3+2];
	    }
	    expan_vert = expanded_vertices;
	}
};