#version 330 core

out vec4 fragColor0;


void main(){
	fragColor0 = vec4(1.0, 0.0, 0.0, 1.0);
	return;
}
