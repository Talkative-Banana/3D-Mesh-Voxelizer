#All the intermediate textures are stored in folder textures
simply run ./build.sh
Textures will be generated when screen turns white and you may close the program by ctrl c on terminal
